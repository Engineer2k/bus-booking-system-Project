<?php
$host = "localhost";
$user = "root";
$password = "Root@123"; // change if needed
$dbname = "myapp";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
